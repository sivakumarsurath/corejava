package com.capgemini.currency.exception;

public class CurrencyException extends Exception{

	public CurrencyException(String message) {
		super(message);
		
	}
	
	
	
	

}
