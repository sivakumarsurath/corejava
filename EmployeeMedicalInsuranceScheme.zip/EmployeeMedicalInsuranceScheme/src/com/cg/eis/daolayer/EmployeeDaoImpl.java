package com.cg.eis.daolayer;

public class EmployeeDaoImpl implements EmployeeDao {
	
	
	
	
	
	
	

}
