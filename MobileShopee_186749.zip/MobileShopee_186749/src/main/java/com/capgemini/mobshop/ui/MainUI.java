package com.capgemini.mobshop.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.capgemini.mobshop.dto.Mobiles;
import com.capgemini.mobshop.exception.MobilesException;
import com.capgemini.mobshop.service.MobileService;
import com.capgemini.mobshop.service.MobileServiceImpl;
import com.capgemini.mobshop.util.MobileById;
import com.capgemini.mobshop.util.MobileByName;
import com.capgemini.mobshop.util.MobileByPrice;

//This package contains main class
/**
 * presentation layer
 * @author ssurath
 *
 */
public class MainUI {
	/**
	 * This is MainUI class
	 * 
	 * @param args
	 */

	public static void main(String[] args) {
		/**
		 * This is the main method
		 */

		Scanner scanner = new Scanner(System.in);
		MobileService mobileservice = new MobileServiceImpl();
		List<Mobiles> mobilelist1 = new ArrayList<Mobiles>();
		try {
			List<Mobiles> mobilelist = mobileservice.getMobileList();
		} catch (MobilesException e1) {
			System.out.println(e1.getMessage());
		}
		boolean deleteFlag = false;
		boolean choiceFlag = false;
		boolean choiceFlag1 = false;
		boolean continueValue = false;
		boolean continueValue1 = false;

		int choice = 0;
		int sequence = 0;
		do {
			do {
				System.out.println("1.Sorting\n2.Delete\n3.Exit");
				try {
					choice = scanner.nextInt();
					choiceFlag = true;
					if (choice > 3) {
						System.out.println("Entered choice should be in between 1,2 and 3");
						choiceFlag = false;
					} else {
						System.out.println("ok! you can proceed");
						choiceFlag = true;
					}
				} catch (InputMismatchException e) {
					System.err.println("Only Integers are allowed!");
					choiceFlag = false;
					scanner.nextLine();
				}
			} while (!choiceFlag);
			switch (choice) {
			case 1: {
				/**
				 * It will display sorting options
				 */
				do {

					System.out.println("Enter your Sorting option\n1.Mobile Name\n2.Mobile Price \n3.Mobile Id");
					int option = scanner.nextInt();
					switch (option) {

					case 1: {
						/**
						 * It will sort by name
						 */
						try {
							mobilelist1 = mobileservice.SortList(option);

							display(mobilelist1);
						} catch (MobilesException e) {
							System.out.println(e.getMessage());
						}

					}
						break;
					case 2: {
						/**
						 * It will sort by pricwe
						 */

						try {
							mobilelist1 = mobileservice.SortList(option);

							display(mobilelist1);
						} catch (MobilesException e) {
							System.out.println(e.getMessage());
						}

					}
						break;

					case 3: {
						/**
						 * It will sort by id
						 */

						try {
							mobilelist1 = mobileservice.SortList(option);

							display(mobilelist1);
						} catch (MobilesException e) {
							System.out.println(e.getMessage());
						}

					}
						break;

					}
					do {
						scanner = new Scanner(System.in);
						String continueChoice = null;
						System.out.println("do you want to continue again [yes/no]");
						continueChoice = scanner.nextLine();
						if (continueChoice.equalsIgnoreCase("yes")) {
							continueValue1 = true;
							choiceFlag1 = false;
							break;
						} else if (continueChoice.equalsIgnoreCase("no")) {
							System.out.println("thank you");
							continueValue1 = false;
							choiceFlag1 = true;
							break;
						} else {
							System.out.println("enter yes or no");
							continueValue1 = false;
							continue;
						}
					} while (!continueValue1);

				} while (!choiceFlag1);
			}
				break;
			case 2: {
				/**
				 * It will delete the entered Id
				 */
			

				System.out.println("Enter Mobile Id to delete");
				int mobileId = scanner.nextInt();

				try {
					mobileservice.deleteMobile(mobileId);
					System.out.println(mobileservice.getList());
				} catch (MobilesException e) {
					System.out.println(e.getMessage());
				}

			}
				break;
			case 3: {
				System.out.println("System getting exited");
				System.exit(0);
			}
				break;
			default: {
				System.out.println("choice must be between 1,2 and 3");
			}
			}
			do {
				scanner = new Scanner(System.in);
				String continueChoice = null;
				System.out.println("do you want to continue again [yes/no]");
				continueChoice = scanner.nextLine();
				if (continueChoice.equalsIgnoreCase("yes")) {
					continueValue = true;
					choiceFlag = false;
					break;
				} else if (continueChoice.equalsIgnoreCase("no")) {
					System.out.println("thank you");
					continueValue = false;
					choiceFlag = true;
					break;
				} else {
					System.out.println("enter yes or no");
					continueValue = false;
					continue;
				}
			} while (!continueValue);

		} while (!choiceFlag);
	}

	static void display(List<Mobiles> mobilelist) {
		for (Mobiles mobile : mobilelist) {
			System.out.println(mobile);
		}
	}
}
