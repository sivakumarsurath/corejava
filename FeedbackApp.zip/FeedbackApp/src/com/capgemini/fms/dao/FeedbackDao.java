package com.capgemini.fms.dao;

import java.util.HashMap;
import java.util.Map;

public class FeedbackDao implements IFeedbackDao {
	
	
	
Map<String, Integer> MathFeedbackMap= new HashMap<>();
	
	Map<String, Integer> EnglishFeedbackMap= new HashMap<>();

	@Override
	public Map<String, Integer> addFeedbackDetails(String name, int rating, String subject) {
	
		return null;
	}

	@Override
	public Map<String, Integer> getFeedbackReport() {
	
		return null;
	}

}
