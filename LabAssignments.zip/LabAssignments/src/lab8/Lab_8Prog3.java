package lab8;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
public class Lab_8Prog3 {
        public static void main(String[] args) {
                FileInputStream fin=null;
                FileOutputStream fout=null;
                try
                {
                    fin = new FileInputStream("src/labworkday2/EvenTerm.java");    
                    fout = new FileOutputStream("src/my.doc");
                    int i=0,line=1,words=0,chaar=1;
                    while(i!=-1) 
                    {  
                        
                        i=fin.read();
                        if(i==' ')
                            words++;
                        fout.write(i);
                        
                        System.out.print((char)i);
                        if(i!=' '||i!='\n')
                            chaar++;
                        
                        if(i=='\n') 
                            line++;
                            
                        
                    }
                    System.out.println("total no of lines:"+line+"\ntotal words:"+words+"\ntotal characters:"+chaar);
                    
                }
                catch (FileNotFoundException e)
                {
                    e.printStackTrace();
                } catch (IOException e) {
                    
                    e.printStackTrace();
                }
            }


        }




