package com.cg.eis.bean;

public class Employee {
	    private int empId;
	    private String name;
	    private String designation;
	    private String insuranceScheme;
	    private double salary;
	    public Employee() {
	        super();
	        // TODO Auto-generated constructor stub
	    }
		public Employee(int empId, String name, String designation, String insuranceScheme, double salary) {
			super();
			this.empId = empId;
			this.name = name;
			this.designation = designation;
			this.insuranceScheme = insuranceScheme;
			this.salary = salary;
		}
		public Employee(String name2, String designation2, String scheme, double salary2) {
			// TODO Auto-generated constructor stub
			this.name = name2;
			this.designation = designation2;
			this.insuranceScheme = scheme;
			this.salary = salary2;
		}
		public int getEmpId() {
			return empId;
		}
		public void setEmpId(int empId) {
			this.empId = empId;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getDesignation() {
			return designation;
		}
		public void setDesignation(String designation) {
			this.designation = designation;
		}
		public String getInsuranceScheme() {
			return insuranceScheme;
		}
		public void setInsuranceScheme(String insuranceScheme) {
			this.insuranceScheme = insuranceScheme;
		}
		public double getSalary() {
			return salary;
		}
		public void setSalary(double salary) {
			this.salary = salary;
		}
		@Override
		public String toString() {
			return " name=" + name + ", designation=" + designation + ", insuranceScheme="
					+ insuranceScheme + ", salary=" + salary + "\n";
		}
	   

	
}
