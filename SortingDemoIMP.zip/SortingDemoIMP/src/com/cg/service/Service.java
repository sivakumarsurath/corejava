package com.cg.service;

import java.util.HashMap;

import com.cg.beans.Product;

public interface Service {

	HashMap<Integer, Product> getallcusto();

}
