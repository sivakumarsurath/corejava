package com.cg;

public class MyGenericClass<T> {

	public void display(T a, T b) {
		System.out.println("A=" + a);
		System.out.println("B=" + b);

	}

	public static void main(String[] args) {
		
		MyGenericClass<Integer> mgc = new MyGenericClass<>();
		mgc.display(10, 20);
		MyGenericClass<Double> mgc1 = new MyGenericClass<>();
		mgc1.display(10.253, 20.253);
		MyGenericClass<String> mgc2 = new MyGenericClass<>();
		mgc2.display("Hello", "java");

	}
}
