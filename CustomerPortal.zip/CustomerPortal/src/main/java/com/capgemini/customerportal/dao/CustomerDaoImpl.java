package com.capgemini.customerportal.dao;

import java.util.Map;
import java.util.logging.Logger;

import com.capgemini.customerportal.bean.Customer;

public class CustomerDaoImpl implements CustomerDAO {
	boolean status = false;
	Logger log = Logger.getLogger("CustomerDaoImpl");

	@Override
	public int addCustomer(Customer customer) {
		log.info("customerdao addcustomer() started");
		Customer c = customerList.put(customer.getCustomerId(), customer);
		log.info("addcustomer(); finished and returning" + customer.getCustomerId());

		return customer.getCustomerId();

	}

	@Override
	public boolean updateCustomer(Customer customer) {
		Customer c = customerList.put(customer.getCustomerId(), customer);
		if (c != null)
			status = true;
		return status;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		Customer customer = customerList.get(customerId);
		if (customer != null)
			status = true;
		return status;
	}

	@Override
	public Customer getCustomer(int customerId) {

		return customerList.get(customerId);
	}

	@Override
	public Map<Integer, Customer> getCustomers() {

		return customerList;
	}

}
