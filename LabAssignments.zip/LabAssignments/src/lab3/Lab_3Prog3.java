package lab3;
import java.util.Arrays;
import java.util.Scanner;

public class Lab_3Prog3 {
	
	    public static int[] getSorted (int[] array) {
	        int y = 0, sum = 0;
	        int array2[] = new int[array.length];
	        for (int i = 0; i < array.length; i++) {
	            sum = 0;
	            while (array[i] > 0) {
	                int rem = 0;
	                rem = array[i] % 10;
	                sum = sum * 10 + rem;
	                array[i] = array[i] / 10;
	            }

	            array2[y] = sum;
	            y++;
	        }
	        Arrays.sort(array2);

	        return array2;
	    }
	    public static void main(String[] args) {
	        @SuppressWarnings("resource")
			Scanner scanner = new Scanner(System.in);
	        System.out.println("size");
	        int size = scanner.nextInt();
	        int array[] = new int[size];
	        System.out.println("enter elements");
	        for (int i = 0; i < size; i++) {
	            array[i] = scanner.nextInt();
	        }
	        int output[] = getSorted(array);
	        for (int i = 0; i < size; i++) {
	            System.out.println(output[i]);
	        }
	    }

	 

	}
	 

