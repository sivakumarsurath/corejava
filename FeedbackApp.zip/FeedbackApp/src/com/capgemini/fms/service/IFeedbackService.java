package com.capgemini.fms.service;

import java.util.Map;

public interface IFeedbackService {

	Map<String, Integer> addFeedbackDetails(String name, int rating, String subject);
	Map<String, Integer> getFeedbackReport();
	void validateTeacherName(String teacherName);
	
	
	
	
}
