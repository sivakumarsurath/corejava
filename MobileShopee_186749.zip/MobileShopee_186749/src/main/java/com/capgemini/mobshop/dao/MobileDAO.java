package com.capgemini.mobshop.dao;

import java.util.List;

import com.capgemini.mobshop.dto.Mobiles;
import com.capgemini.mobshop.exception.MobilesException;
/**
 * dao package
 * @author ssurath
 *
 */

public interface MobileDAO {

	Mobiles deleteMobile(int mobcode) throws MobilesException;

	List<Mobiles> getMobileList()throws MobilesException;
	
	List<Mobiles> getList()throws MobilesException;

}
