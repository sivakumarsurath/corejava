package comcapgemini.productmgmt.service;

import java.util.Map;
import java.util.regex.Pattern;

import com.capgemini.productmgmt.dao.ProductDAO;
import com.capgemini.productmgmt.exception.ProductException;


public class ProductServiceImpl implements IProductService {
ProductDAO dao=new ProductDAO();
	@Override
	public int updateProducts(String Category, int hike) throws ProductException {
		
		return 0;
	}

	@Override
	public Map<String, Integer> getProductDetails() throws ProductException {
		
		return dao.getProductDetails();
	}

	@Override
	public boolean ProductCategory(String productCategory) throws ProductException {
		
		return false;
	}

	@Override
	public boolean validateProduct(int product) throws ProductException {
		
		return false;
	}

	@Override
	public boolean validateProductName(String productName) throws ProductException {
		return false;
	
	}
	
	

}
