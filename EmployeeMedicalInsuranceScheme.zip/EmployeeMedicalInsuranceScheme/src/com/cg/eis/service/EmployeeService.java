package com.cg.eis.service;

import com.cg.eis.exception.EmployeeException;

public interface EmployeeService {

	public String AssignScheme(double salary, String designation) throws EmployeeException;

	public int generateId() throws EmployeeException;

	public boolean validateName(String name) throws EmployeeException ;

	public boolean validateSalary(double salary)throws EmployeeException ;

	public boolean validateDesignation(String designation) throws EmployeeException;

	
}
