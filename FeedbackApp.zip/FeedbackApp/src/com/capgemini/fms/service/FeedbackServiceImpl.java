package com.capgemini.fms.service;

import java.util.Map;

public class FeedbackServiceImpl implements IFeedbackService{

	@Override
	public Map<String, Integer> addFeedbackDetails(String name, int rating, String subject) {
		
		return null;
	}

	@Override
	public Map<String, Integer> getFeedbackReport() {
		
		return null;
	}

	@Override
	public void validateTeacherName(String teacherName) {
		// TODO Auto-generated method stub
		
	}

	
	
	
	
}
