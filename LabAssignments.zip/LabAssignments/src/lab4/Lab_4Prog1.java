package lab4;

import java.util.Scanner;

public class Lab_4Prog1{

	public int cubes(int value1) {

		int rem, cube = 0;
		while (value1 > 0) {

			rem = value1 % 10;
			value1 = value1 / 10;

			cube = (int) (cube + Math.pow(rem, 3));
		}
		return cube;
	}

	public static void main(String[] args) {

		Lab_4Prog1 operator = new Lab_4Prog1();
		System.out.println("enter num");
		Scanner scanner = new Scanner(System.in);
		int value = scanner.nextInt();
		int result = operator.cubes(value);
		System.out.println(result);
		scanner.close();
	}
}