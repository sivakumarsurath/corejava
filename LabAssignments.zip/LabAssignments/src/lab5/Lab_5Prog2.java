package lab5;

import java.util.Scanner;

public class Lab_5Prog2 {
	int n;

	public void recursive(int a, int b, int c, int r) {
		if (c <= r) {
			c = a + b;
			a = b;
			b = c;
			System.out.print(c + " ");
			recursive(a, b, c, r);
		}
	}

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter range");
		int range = scanner.nextInt();
		int a = 1, b = 1, c = 0;
		System.out.print("The Fibonacci Sequence is ");
		System.out.print(a + " ");
		System.out.print(b + " ");
		Lab_5Prog2 fibonacciseq = new Lab_5Prog2();
		fibonacciseq.recursive(a, b, c, range);
	}
}