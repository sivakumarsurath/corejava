package lab13;

import java.util.Scanner;

public class Lab_13Prog2Impl {
	public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter name :");
        String name1=sc.nextLine();
        
        Lab_13Prog2 obj=(name)->{
            
            String name2 ="";
            for(int i=0;i<name.length();i++) {
                name2=name2+name.charAt(i)+" ";
            }
            System.out.println("New String is :"+name2);
            return name2;
            
    };
    System.out.println(obj.AddSpace(name1));
    

 

}

 

}

