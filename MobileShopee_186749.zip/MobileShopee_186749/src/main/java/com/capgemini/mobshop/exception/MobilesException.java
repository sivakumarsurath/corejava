package com.capgemini.mobshop.exception;
//This is the exception package

public class MobilesException extends Exception {

	public MobilesException(String message) {
		super(message);
		
	}

	
}
