package com.cg.vms.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.vms.exceptions.VMSException;
import com.cg.vms.model.Vehicle;
import com.cg.vms.service.VehicleServiceImpl;

public class VechileDaoImplTest {
	VehicleServiceImpl vp=null;
	@Before
	public void setUp() throws Exception {
		vp=new VehicleServiceImpl();
		
		
	}

	@After
	public void tearDown() throws Exception {
		
		vp=null;
	}

	@Test
	public void testaddVehicleNull() {
		Vehicle vehicle = new Vehicle("Suziki", 50000,"Honda");
		try {
			vp.addVehicle(vehicle);
			assertNull(vehicle);
		} catch (VMSException e) {
			 
			e.printStackTrace();
		}
	}

	
	@Test
	public void testaddVehicle() {
		Vehicle vehicle = new Vehicle("Suziki", 50000,"Honda");
		try {
			vp.addVehicle(vehicle);
			assertNotNull(vehicle);
		} catch (VMSException e) {
			
			e.printStackTrace();
		}
	}
	
	@Test
	public void testgetAllVehicles() {
		Vehicle vehicle = new Vehicle("Suziki", 50000,"Honda");
		try {
			vp.getAllVehicles();
			assertNotNull(vehicle);
		} catch (VMSException e) {
			
			e.printStackTrace();
		}
	}
	 
	
	
}
