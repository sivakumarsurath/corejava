package comcapgemini.productmgmt.service;

import java.util.Map;

import com.capgemini.productmgmt.exception.ProductException;

public interface IProductService {
	
	public int updateProducts(String Category, int hike) throws ProductException;
	public Map<String,Integer> getProductDetails() throws ProductException;
	public boolean ProductCategory(String productCategory) throws ProductException;
	public boolean validateProduct(int product) throws ProductException;
	public boolean validateProductName(String productName)throws ProductException;
	
	
	
	
	

}
