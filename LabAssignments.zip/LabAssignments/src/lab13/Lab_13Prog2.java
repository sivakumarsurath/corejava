package lab13;


	public interface Lab_13Prog2 {
		String AddSpace(String name);
			 
}
