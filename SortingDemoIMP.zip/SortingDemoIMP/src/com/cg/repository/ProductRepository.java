package com.cg.repository;

import java.util.HashMap;

import com.cg.beans.Product;

public class ProductRepository {
	
	public static HashMap<Integer,Product> map=new HashMap<>();
	
	public static HashMap<Integer,Product> getAllProducts(){
		
		map.put(44, new Product(44,"laptop",98989));
		map.put(33, new Product(33,"desktop",58456));
		map.put(22, new Product(22,"cpu",9898));
		map.put(11, new Product(11,"mouse",580));
		map.put(55, new Product(55,"keyboard",900));
		return map;

	}static {
		map.put(44, new Product(44,"laptop",98989));
		map.put(33, new Product(33,"desktop",58456));
		map.put(22, new Product(22,"cpu",9898));
		map.put(11, new Product(11,"mouse",580));
		map.put(55, new Product(55,"keyboard",900));
		
	}
	public HashMap<Integer, Product> ggdhasm() {
		// TODO Auto-generated method stub
		return map;
	}
	

}
