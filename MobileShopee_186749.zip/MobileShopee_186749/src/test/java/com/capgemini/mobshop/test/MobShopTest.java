package com.capgemini.mobshop.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.mobshop.dao.MobileDAOImpl;
import com.capgemini.mobshop.dto.Mobiles;
import com.capgemini.mobshop.exception.MobilesException;

public class MobShopTest {
	   MobileDAOImpl dao=null;
	@Before
	public void setUp() throws Exception {
		  dao=new MobileDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		 dao=null;
	}

	@Test
	public void testDeleteMobile() {
		try {
			assertEquals(true, dao.deleteMobile(102));
			assertNotEquals(true, dao.deleteMobile(101));
		} catch (MobilesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Test
	public void testNegativeDeleteMobile() {
		try {
			assertNotEquals(false, dao.deleteMobile(101));
		} catch (MobilesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testGetMobileList() {
		 List<Mobiles> mobileList;
		try {
			mobileList = dao.getMobileList();
			assertEquals(4, mobileList.size());
		} catch (MobilesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
         
	}
	@Test
	public void testnegativeGetMobileList() {
		 List<Mobiles> mobileList;
		try {
			mobileList = dao.getMobileList();
			assertEquals(4, mobileList.size());
			assertNotEquals(2, mobileList.size());
		} catch (MobilesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
         
	}
	@Test
	public void testGetList() {
try {
	List<Mobiles> list1=dao.getList();
	assertEquals(4, list1.size());
	assertNotEquals(3, list1.size());
} catch (MobilesException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}		
	}
	@Test
	public void testNegativeGetList() {
try {
	List<Mobiles> list1=dao.getList();
	assertNotEquals(4, list1.size());
} catch (MobilesException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}		
	}

}
