package com.cg.eis.daolayer;

public interface EmployeeDao {

}
