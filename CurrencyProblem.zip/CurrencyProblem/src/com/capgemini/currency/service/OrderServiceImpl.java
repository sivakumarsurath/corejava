package com.capgemini.currency.service;

import com.capgemini.currency.bean.Order;

public class OrderServiceImpl implements OrderService{

	@Override
	public void validate(int quantity) {
		
		
	}

	@Override
	public int addOrderService(Order order) {
		
		return 0;
	}

	
	
	
}
