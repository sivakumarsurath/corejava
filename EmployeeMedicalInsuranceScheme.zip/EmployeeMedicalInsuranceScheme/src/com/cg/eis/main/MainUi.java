package com.cg.eis.main;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;
import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.EmployeeService;
import com.cg.eis.service.EmployeeServiceImpl;

/**
 * 
 * @author ssurath
 * @version 1.0
 */

public class MainUi {
	/**
	 * 
	 * @param args
	 */

	public static void main(String[] args) {

		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		EmployeeService employeeService = new EmployeeServiceImpl();
		Map<Integer, Employee> employee = new HashMap<>();
		boolean continueValue = false;
		String continueChoice;

		boolean flag = false;
		do {
			System.out.println("1.Add employee details\n2.Display employee details\n3.exit");
			System.out.println("select a option");
			try {
				int option = scanner.nextInt();
				flag = true;
				switch (option) {
				case 1: {
					String name = null;
					boolean val = false;

					do {
						System.out.println("enter name of the employee");

						try {
							name = scanner.next();

							employeeService.validateName(name);
							val = true;

						} catch (EmployeeException e) {

							val = false;
							System.out.println(e.getMessage());
						}

					} while (!val);

					String designation = "";
					boolean designationflag = false;

					do {
						System.out.println("enter the employee designation");

						try {
							designation = scanner.next();

							employeeService.validateDesignation(designation);
							designationflag = true;

						} catch (EmployeeException e) {

							val = false;
							System.out.println(e.getMessage());
						}
					} while (!designationflag);
					double salary = 0.000;
					boolean salFlag = false;
					do {
						System.out.println("enter the employee salary");
						try {

							salary = scanner.nextDouble();

							employeeService.validateSalary(salary);
							salFlag = true;

						} catch (EmployeeException e) {
							salFlag = false;
							System.out.println(e.getMessage());
						}

						catch (InputMismatchException e) {
							salFlag = false;
							System.err.println("salary must be in digits");
							scanner.nextLine();
						}
					} while (!salFlag);

					int id = 0;
					try {
						id = employeeService.generateId();
						System.out.println(" succesfully registered with id :" + id);
					} catch (EmployeeException e) {

						System.out.println("not registered succesfully");
					}
					String scheme = null;
					try {
						scheme = employeeService.AssignScheme(salary, designation);
					} catch (EmployeeException e) {

						System.out.println("no scheme available for given details");
					}

					employee.put(id, new Employee(name, designation, scheme, salary));

				}
					break;

				case 2: {
					try {
						if (employee != null)
							System.out.println("employee details" + employee);
					} catch (Exception e) {

						System.err.println("no details to display");
					}

				}

					break;
				case 3:
					System.out.println("Thank u, visit again");
					System.exit(0);
					break;

				default: {
					flag = false;
					System.out.println("choice must between 1 and 2");
				}
					break;
				}
				do {
					scanner = new Scanner(System.in);
					System.out.println("do you want to continue again [yes/no]");
					continueChoice = scanner.nextLine();
					if (continueChoice.equalsIgnoreCase("yes")) {
						continueValue = false;
						flag = false;
						break;
					} else if (continueChoice.equalsIgnoreCase("no")) {
						System.out.println("thank you and have a nice day");
						continueValue = false;
						flag = true;
						break;
					} else {
						System.out.println("enter yes or no");
						continueValue = true;
						continue;
					}
				} while (continueValue);
			} catch (InputMismatchException e) {

				flag = true;
				System.out.println("Entered choice must be in digits");
			}
		} while (!flag);
	}

}
