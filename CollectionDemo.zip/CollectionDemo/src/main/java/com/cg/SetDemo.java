package com.cg;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class SetDemo {

	public static void main(String[] args) {
		// HashSet<String> set=new HashSet<>();//random
		// LinkedHashSet<String> set=new LinkedHashSet<>();//order wise sequence
		TreeSet<String> set = new TreeSet<>();// sorted in Ascending
		set.add("java");
		set.add("spring");
		set.add("jee");
		set.add("angular");
		set.add("html");
		// set.add(null);
		System.out.println(set);

	}

}
