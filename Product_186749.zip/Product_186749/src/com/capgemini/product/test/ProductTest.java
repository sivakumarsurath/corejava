package com.capgemini.product.test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ProductTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		
	}

}
