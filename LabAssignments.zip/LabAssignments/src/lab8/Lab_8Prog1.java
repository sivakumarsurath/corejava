package lab8;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Lab_8Prog1 {

	public static void main(String[] args) {
		int temp, sum = 0;
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter numbers");
		String number = scanner.nextLine();
		StringTokenizer st = new StringTokenizer(number);
		while (st.hasMoreTokens()) {
			System.out.println(temp = Integer.parseInt(st.nextToken()));
			sum = sum + temp;

		}
		System.out.println("sum:" + sum);

	}

}
