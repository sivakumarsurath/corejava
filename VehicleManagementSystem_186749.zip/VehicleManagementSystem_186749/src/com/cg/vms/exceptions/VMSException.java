package com.cg.vms.exceptions;

public class VMSException extends Exception {

	public VMSException(String message) {
		super(message);
	}
}
