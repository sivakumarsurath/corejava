package com.cg.eis.service;

import java.util.regex.Pattern;

import com.cg.eis.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService {

	@Override
	public String AssignScheme(double salary, String designation) throws EmployeeException {
		
		String insuranceScheme=null;
		if(salary<5000 && designation.equals("clerk"))
		{
			insuranceScheme="no scheme assigned";
		}
		if(salary>5000 && salary<20000 && designation.equals("System Asssociate"))
		{
			insuranceScheme="Scheme C";
		}
		if(salary>=20000 && salary<40000 && designation.equals("programmer"))
		{
			insuranceScheme="Scheme B";
		}
		if(salary>=40000 && designation.equals("Manager") && salary<=90000)
		{
			insuranceScheme="Scheme A";
		}
		else
		{
			throw new EmployeeException("salary must be less than 90000");
		}
		return insuranceScheme;
	}

	@Override
	public int generateId() throws EmployeeException {
	
		double generatedId;
		generatedId=Math.random()*1000;
		int id=(int)generatedId;
		return id;
	}

	@Override
	public boolean validateName(String name) throws EmployeeException {
		
		boolean result=false;
		String pattern= "[A-Z]{1}[a-zA-Z]{4,}";
		
			if(!Pattern.matches(pattern, name))
			{
				 
				 throw new EmployeeException("name should be start with capital letter and minimum 5 characters should present");
			}
			else
			{
				result=true;
			}
		
		
		return result;
	}

	@Override
	public boolean validateSalary(double salary) throws EmployeeException {
		
		boolean salFlag=false;
		
			if(salary>40000) {
				
				return salFlag;
			}
			else {
		
			
throw new EmployeeException("sal must be greater than 40000");


		}
		
	}

	@Override
	public boolean validateDesignation(String designation) throws EmployeeException {
		boolean result=false;
		String pattern= "[A-Z]{1}[a-zA-Z]{4,}";
		
			if(!Pattern.matches(pattern,designation ))
			{
				 
				 throw new EmployeeException("First letter should be capital enter string only");
			}
			else
			{
				result=true;
			}
		
		
		return result;
	}
	}


