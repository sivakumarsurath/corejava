package lab13;

	import java.util.Scanner;

	interface Myreference{
	    void factorial(int a);
	}

	public class Lab_13Prog5 {
		 
	  public void fact(int c) {
	      int n=1;
	      for(int i=1;i<=c;i++) {
	          n=n*i;
	      }
	      System.out.println("factorial of a given number"+n);
	  } public static void main(String[] args) {
		  Lab_13Prog5 obj=new Lab_13Prog5();
		    Myreference ref=obj::fact;
		    int num;
		    System.out.println("eneter number");
		    Scanner sc=new Scanner(System.in);
		    num=sc.nextInt();
		    
		    ref.factorial(num);
		    }

		 

		}
		 


