package com.capgemini.fms.ui;

import java.util.Scanner;

import com.capgemini.fms.service.FeedbackServiceImpl;
import com.capgemini.fms.service.IFeedbackService;
/**
 * 
 * @param args
 */

public class Client {
	
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		
		String continueChoice;
		boolean continueValue = false;

		Scanner scanner = null;
		
		do {
			System.out.println("welcome to the application and have a nice day");
			System.out.println("1.enter the details");
			System.out.println("2.display the details");
			System.out.println("3.exit");
			IFeedbackService feedback=new FeedbackServiceImpl();
			
			int choice = 0;
			boolean choiceFlag = false;
 
			do {
				
				scanner = new Scanner(System.in);
				System.out.println("Enter input:");
					choice = scanner.nextInt();
					choiceFlag = true;

		
					switch (choice) {

					case 1:
						
						String TeacherName="";
						boolean TeacherNameFlag=false;
						do {

						System.out.println("enter teacher name");
						
						TeacherName = scanner.nextLine();
						try {
						feedback.validateTeacherName(TeacherName);
						TeacherNameFlag=true;
						
						
						} 
						catch (FBException e) {
							TeacherNameFlag = false;
							System.err.println(e.getMessage());
						}
			         	while (!TeacherNameFlag);
						
						
						
						break;
						
					case 2:
						break;
					case 3:
						System.out.println("thank you");
						break;
						
						default :
							System.out.println("invalid choice");
						
						break;
				
				
				
			} while (!choiceFlag);
			
			
			
		} while (!continueValue);}	}}	

					
						
							
						