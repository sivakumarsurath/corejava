package com.capgemini.mobshop.service;

import java.util.List;
/**
 * service package
 */

import com.capgemini.mobshop.dto.Mobiles;
import com.capgemini.mobshop.exception.MobilesException;

public interface MobileService {
	/**
	 * It is service interface layer having only method declaration
	 * @return
	 * @throws MobilesException
	 */
	public List<Mobiles> getMobileList()throws MobilesException;
	public Mobiles deleteMobile(int mobcode)throws MobilesException;
	public List<Mobiles> SortList(int criteria)throws MobilesException;
	List<Mobiles> getList()throws MobilesException;
}
