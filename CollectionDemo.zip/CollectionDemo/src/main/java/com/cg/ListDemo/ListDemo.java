package com.cg.ListDemo;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Stack;
import java.util.Vector;

public class ListDemo {
	public static void main(String[] args) {
		List<Integer> list1 = new ArrayList<>();
		list1.add(10);
		list1.add(new Integer(20));
		list1.add(30);
		list1.add(10);
		list1.add(40);
		System.out.println(list1);
		System.out.println("size:" + list1.size());
		System.out.println("contains(10):" + list1.contains(10));
		System.out.println("1st value:" + list1.get(1));
		System.out.println("remove(30):" + list1.remove(new Integer(30)));
		System.out.println("After remove:" + list1);

		LinkedList<Integer> list2 = new LinkedList<>();
		list2.add(10);
		list2.add(new Integer(20));
		list2.add(30);
		list2.add(10);
		list2.add(40);
		System.out.println(list2);
		list2.addFirst(53);
		list2.addLast(536);
		System.out.println(list2);
		list2.removeLastOccurrence(new Integer(55));
		System.out.println(list2);
		list2.offer(56);
		list2.offer(86);
		System.out.println("Top value:" + list2.peek());// get top value
		list2.poll();// remove top value
		System.out.println("after remove:" + list2);
//iterating values using iterator
		System.out.println("Iterator");
		Iterator<Integer> it = list2.iterator();
		while (it.hasNext()) {
			System.out.println(it.next() + " ");
		}
		// for loop
		System.out.println("For loop");
		for (Integer i : list2) {
			System.out.println(i + " ");

		}
		Vector<String> v = new Vector<>(3, 2);
		System.out.println("capacity:" + v.capacity());
		System.out.println("size:" + v.size());
		v.add("java");
		v.addElement("jee");
		v.add("spring");
		v.add(1, "angular");
		System.out.println(v);
		System.out.println("\ncapacity:" + v.capacity());
		System.out.println("size:" + v.size());
		// extract the value using enumeration
		Enumeration<String> en = v.elements();
		while (en.hasMoreElements()) {
			System.out.println(" " + en.nextElement());

		}
		Stack<Integer> stack=new Stack<>();
		stack.add(11);
		stack.push(22);
		stack.push(33);
		System.out.println(stack);
		System.out.println("Top Value:"+stack.peek());
		stack.pop();
		System.out.println("after pop:"+stack);
		
	}

}
