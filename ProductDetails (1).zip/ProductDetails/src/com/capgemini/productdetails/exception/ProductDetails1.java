package com.capgemini.productdetails.exception;

public class ProductDetails1 extends Exception {
	

	public ProductDetails1(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
                                                                           	public ProductDetails1(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public ProductDetails1(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	
	public ProductDetails1(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	

}
